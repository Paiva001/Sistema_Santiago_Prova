/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tools;

import java.util.Date;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JTextField;

/**
 *
 * @author u11289134103
 */
public class Util {
    public static void habilitar(boolean valor, JComponent ... comp){
        for  (int i = 0; i < comp.length; i++){
            comp[i].setEnabled(valor);
        }
    }
    public static void limpar (JComponent ... comp){
        for (int i = 0; i < comp.length; i++){
            if (comp[i] instanceof JTextField){
            ((JTextField)comp[i]).setText("");
            }
            if (comp[i] instanceof JComboBox){
                ((JComboBox)comp[i]).setSelectedIndex(-1);
            }
            if (comp[i] instanceof JCheckBox){
                ((JCheckBox)comp[i]).setSelected(false);
            }
        }
    }
    public static int srtToInt(String cad){
        return 0;
    }
    public static double srtDouble(String cad){
        return 0;
    }
    public static Date strDate(String cad){
        return null;
    }
    public static String intToStr(int num){
    return"";
    }
    public static String doubleToStr(int num){
        return"";
    }
    public static String dateToSrt(int num){
        return null;
    }
}

